#!/bin/sh

cd /v2c/disk/

tar c opt/tomcat 2> /dev/null
