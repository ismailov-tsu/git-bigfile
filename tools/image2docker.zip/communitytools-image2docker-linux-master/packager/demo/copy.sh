#!/bin/sh
mkdir -p /v2c/disk
tar xf payload.tar -C /v2c/disk/
